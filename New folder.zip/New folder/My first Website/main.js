function changecolor() {
    document.getElementById("h1").style.color = "purple";
}

function changename() {
    document.getElementById("h2").innerHTML = "~ Sampurna Gope";
    document.getElementById("h2").style.color = "magenta";
}
